package base;

public enum BlasterState {
	NORM_ENEMY,
	ULTRA_ENEMY,
	NORM_MAIN,
	SUPER_MAIN
}
