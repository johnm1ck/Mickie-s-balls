package base;

public interface Transformable {
	void boom();
}
